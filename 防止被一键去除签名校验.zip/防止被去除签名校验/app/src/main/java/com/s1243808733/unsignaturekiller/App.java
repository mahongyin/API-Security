package com.s1243808733.unsignaturekiller;

import android.app.Application;
import android.content.Context;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class App extends Application {

	@Override
	protected void attachBaseContext(Context base) {
		//因为是从这里被hook的，所以在onCreate重置
		super.attachBaseContext(base);
	}

	@Override
	public void onCreate() {
		super.onCreate();

		//重置PackageManager
		//resetPackageManager(getBaseContext());

	}

	/**
	 * 通过重置PackageManager防止getPackageInfo方法被代理设置
	 * 亲测MT管理器（当前2.9.1）的一键去签名校验(包括加强版)无效！
	 * 当然如果别人反编译把代码删除的话那就没办法了
	 */
	public static void resetPackageManager(Context baseContext) {
		try {
			//重置全局sPackageManager对象
			reset1: {
				Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
				Field sPackageManagerField = activityThreadClass.getDeclaredField("sPackageManager");
				sPackageManagerField.setAccessible(true);
				sPackageManagerField.set(activityThreadClass, null);
				//因为上面已经把sPackageManager变量设置为null了，调用这个方法重新赋值
				Method getPackageManagerMethod=activityThreadClass.getDeclaredMethod("getPackageManager");
				getPackageManagerMethod.setAccessible(true);
				getPackageManagerMethod.invoke(activityThreadClass);
			}
			//重置当前上下文mPackageManager对象
			reset2: {
				Class<?> baseContextClass=baseContext.getClass();
				Field mPackageManagerField=baseContextClass.getDeclaredField("mPackageManager");
				mPackageManagerField.setAccessible(true);
				mPackageManagerField.set(baseContext, null);
				//重新设置为已经重置好的sPackageManager
				Method getPackageManagerMethod=baseContextClass.getDeclaredMethod("getPackageManager");
				getPackageManagerMethod.setAccessible(true);
				getPackageManagerMethod.invoke(baseContext);
				//baseContext.getPackageManager();
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

}

