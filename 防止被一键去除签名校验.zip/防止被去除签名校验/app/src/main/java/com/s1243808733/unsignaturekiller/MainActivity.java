package com.s1243808733.unsignaturekiller;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView info; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

		info = (TextView)findViewById(R.id.info);

		check();
		info.append("↓重置PackageManager之后↓\n\n");
		App.resetPackageManager(getBaseContext()); //重置PackageManager
		check();
    }


	/**
	 * 正常通过判断签名哈希的方法来判断应用是不是被修改
	 */
	private void check() {
		PackageManager pm=getPackageManager();
		try {
			PackageInfo packageInfo=pm.getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
			int signatureHashCode=packageInfo.signatures[0].hashCode();
			StringBuilder sb=new StringBuilder();
			sb.append("签名哈希 = " + signatureHashCode).append("\n");
			if (signatureHashCode == 1637111176) { //你的签名哈希
				sb.append("未被修改");
			} else {
				sb.append("被修改了");
			}
			sb.append("\n\n");
			info.append(sb);

		} catch (PackageManager.NameNotFoundException e) {}

	}

} 
